# What is project about?

Learn modern react by creating project. This is a simple project that generates random password!

It's written for the blog, so it's not very good for a production use. But this will build up the foundation for the learning react js!

[Screenshot]

# How to run this project?

Go to folder using terminal and run:

```
npm install // for installing all the dependencies
npm start // for running the project
```

## Blog url 
https://blog.nerdjfpb.com/random-password-generator-learn-modern-react-js-for-free/

## Live url
https://nerdjfpb.github.io/react-password-gen/

## Screenshot

![Screenshot](https://github.com/nerdjfpb/react-password-gen/blob/master/screenshot.png)
